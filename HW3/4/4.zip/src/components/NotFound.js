import { useParams } from "react-router-dom";
const NotFound = () => {
  return "404 not found!";
};

export default NotFound;
